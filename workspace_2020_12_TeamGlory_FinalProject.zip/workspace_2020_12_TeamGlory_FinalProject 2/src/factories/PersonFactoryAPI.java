package factories;

import models.Person;

public abstract class PersonFactoryAPI {
	public abstract Person getObject();
}
